// Télécharge les polices (sous-ensemble latin) pour les héberger avec le site.
// À lancer une fois, sur une machine connectée à Internet : `npm run fonts`, puis `npm run build`.
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const OUT = new URL('../src/fonts/', import.meta.url).pathname;
const CSS_URL =
  'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=EB+Garamond:wght@400;500&family=Parisienne&display=swap';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
const PRELOAD = new Set(['Cormorant Garamond-normal-500', 'EB Garamond-normal-400', 'Parisienne-normal-400']);

const css = await (await fetch(CSS_URL, { headers: { 'User-Agent': UA } })).text();
const blocks = [...css.matchAll(/\/\*\s*([\w-]+)\s*\*\/\s*@font-face\s*{([^}]*)}/g)].filter(([, subset]) => subset === 'latin');
if (!blocks.length) throw new Error('Aucune police trouvée : vérifiez la connexion.');

mkdirSync(OUT, { recursive: true });
const faces = [];
const seen = new Set();
for (const [, , body] of blocks) {
  const family = body.match(/font-family:\s*'([^']+)'/)[1];
  const style = body.match(/font-style:\s*(\w+)/)[1];
  const weight = body.match(/font-weight:\s*(\d+)/)[1];
  const url = body.match(/url\(([^)]+)\)/)[1];
  const key = `${family}-${style}-${weight}`;
  if (seen.has(key)) continue;
  seen.add(key);
  const file = `${family.toLowerCase().replace(/\s+/g, '-')}-${style}-${weight}.woff2`;
  const buf = Buffer.from(await (await fetch(url)).arrayBuffer());
  writeFileSync(join(OUT, file), buf);
  faces.push({ family, style, weight, file, preload: PRELOAD.has(key) });
  console.log(`✓ ${file} (${(buf.length / 1024).toFixed(0)} Ko)`);
}
writeFileSync(join(OUT, 'fonts.json'), JSON.stringify(faces, null, 2));
console.log('Polices prêtes. Lancez `npm run build`.');
