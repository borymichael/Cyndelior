# Cyndélior · site vitrine

Site statique de 4 pages (plus les mentions légales et une page 404) pour Cyndel Bory : bijoux en pierres naturelles et lithothérapie, à Cuzieu (Loire).

Il n'a aucune dépendance ni framework. Chaque page pèse environ 10 Ko une fois compressée, avec le CSS et le JS inclus directement dans la page.

## Structure

```
site.config.json      ← coordonnées, domaine, formulaire (à modifier ici uniquement)
build.mjs             ← assemble les pages → dist/ (site) et preview/ (aperçu)
src/pages/            ← contenu de chaque page
src/partials/         ← en-tête, pied de page, barre d'action mobile
src/styles.css        ← design system (couleurs, typographies, composants)
src/main.js           ← menu mobile
src/form.js           ← formulaire devis / rendez-vous / question
src/static/           ← favicon, image de partage, en-têtes de sécurité
scripts/fetch-fonts.mjs
tests/qa.py           ← contrôles automatiques (Playwright)
```

## Commandes

| Commande | Rôle |
|---|---|
| `npm run fonts` | Télécharge les polices pour les héberger avec le site (à faire une fois) |
| `npm run build` | Génère `dist/` |
| `npm run dev` | Build puis serveur local sur http://localhost:8080 |
| `npm test` | Build puis contrôles : liens, titres, débordements mobiles, formulaire, console |

Les tests nécessitent Python 3 et Playwright (`pip install playwright && playwright install chromium`).

## Mise en ligne (Netlify, recommandé)

1. `npm run fonts`, puis `npm run build`
2. Glisser-déposer le dossier `dist/` sur https://app.netlify.com/drop, ou relier le dépôt Git avec la commande de build `npm run build` et le dossier de publication `dist`
3. Brancher le domaine (par exemple cyndelior.fr) dans *Domain settings*
4. Si le domaine final n'est pas `https://www.cyndelior.fr`, modifier `url` dans `site.config.json` et relancer le build : les URL canoniques, le sitemap et l'image de partage en dépendent

Le fichier `_headers` (sécurité et cache) est pris en charge par Netlify et Cloudflare Pages.

## Activer l'envoi du formulaire

Sans service d'envoi, le formulaire prépare un message que le visiteur envoie depuis sa messagerie. Rien n'est perdu, mais cela demande une étape de plus au visiteur.

Pour un envoi direct :

1. Créer un compte gratuit sur https://formspree.io (50 envois par mois en gratuit)
2. Créer un formulaire avec l'adresse email de réception, puis copier son URL (`https://formspree.io/f/xxxxxxx`)
3. La coller dans `formEndpoint` dans `site.config.json`, puis lancer `npm run build`
4. Faire un premier envoi de test pour confirmer l'adresse

Cette URL n'est pas une clé secrète : elle peut figurer dans le code. Formspree applique son propre filtrage anti-spam en plus du champ piège du site. Si vous choisissez un autre service, adaptez `connect-src` dans `src/static/_headers`.

## Avis clients

La section « Leurs mots, leurs histoires » s'affiche sur l'accueil dès qu'au moins un avis figure dans `site.config.json`. Sans avis, elle est masquée sur le site publié. Ajoutez uniquement de vrais avis, avec l'accord des personnes :

```json
"reviewsUrl": "https://g.page/r/…/review",
"reviews": [
  { "name": "Claire M.", "city": "Saint-Galmier", "jewel": "Bracelet sur mesure", "rating": 5, "source": "Google", "text": "…" }
]
```

`reviewsUrl` (facultatif) ajoute un lien « Lire tous les avis », par exemple vers la fiche Google.

## À compléter avant la mise en ligne

- Email, téléphone, réseaux sociaux : `site.config.json` (le téléphone s'affiche automatiquement dès qu'il est renseigné)
- Mentions légales : adresse, SIRET, hébergeur, service de formulaire (repérés en jaune sur la page)
- Photos : les visuels actuels (`src/static/photo-*.webp`) viennent de la planche de style. Remplacez-les par de vraies photos des créations, au format 4:3 ou 4:5, environ 1200 px de large, en WebP de moins de 150 Ko. Le portrait de Cyndel (page À propos) reste à fournir
- Textes de l'histoire et de la démarche (page À propos) : à relire et personnaliser par Cyndel
