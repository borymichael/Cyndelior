// Build statique Cyndélior : assemble les pages, injecte la config, inline CSS/JS.
// Sorties : dist/ (site à déployer) et preview/ (aperçu hébergé).
import { readFileSync, writeFileSync, mkdirSync, rmSync, readdirSync, copyFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const ROOT = new URL('.', import.meta.url).pathname;
const SRC = join(ROOT, 'src');
const cfg = JSON.parse(readFileSync(join(ROOT, 'site.config.json'), 'utf8'));
const read = (p) => readFileSync(join(SRC, p), 'utf8');
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// ---------- Polices : locales si `npm run fonts` a été lancé, sinon Google Fonts ----------
const FONT_DIR = join(SRC, 'fonts');
const localFonts = existsSync(FONT_DIR) ? readdirSync(FONT_DIR).filter((f) => f.endsWith('.woff2')) : [];
export const GOOGLE_FONTS =
  'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=EB+Garamond:wght@400;500&family=Parisienne&display=swap';

function fontHead() {
  if (!localFonts.length) {
    return `<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="${GOOGLE_FONTS}">`;
  }
  const faces = JSON.parse(readFileSync(join(FONT_DIR, 'fonts.json'), 'utf8'));
  const css = faces
    .map((f) => `@font-face{font-family:"${f.family}";font-style:${f.style};font-weight:${f.weight};font-display:swap;src:url(/fonts/${f.file}) format("woff2")}`)
    .join('');
  const preload = faces
    .filter((f) => f.preload)
    .map((f) => `<link rel="preload" href="/fonts/${f.file}" as="font" type="font/woff2" crossorigin>`)
    .join('');
  return `${preload}<style>${css}</style>`;
}

// ---------- Pictogrammes (trait fin, repris de la planche de style) ----------
const ICONS = {
  lotus: '<path d="M12 19c-2.8-1.9-4-4.6-4-7.6 1.9.9 3.4 2.8 4 4.8.6-2 2.1-3.9 4-4.8 0 3-1.2 5.7-4 7.6z"/><path d="M12 15.6c-1.4-2.7-1.4-5.8 0-9.1 1.4 3.3 1.4 6.4 0 9.1z"/><path d="M8.2 17C5.3 16.5 3.4 14.6 3 12c1.9 0 3.7.7 5 1.8M15.8 17c2.9-.5 4.8-2.4 5.2-5-1.9 0-3.7.7-5 1.8"/><path d="M4 20h16"/>',
  star: '<path d="M12 3c.6 4.6 1.9 6.4 6 7-4.1.6-5.4 2.4-6 7-.6-4.6-1.9-6.4-6-7 4.1-.6 5.4-2.4 6-7z"/><path d="M5 3.5v3M3.5 5h3M19 16.5v3M17.5 18h3"/>',
  heart: '<path d="M12 20s-7.5-4.6-7.5-10.2A4.1 4.1 0 0 1 12 7.4a4.1 4.1 0 0 1 7.5 2.4C19.5 15.4 12 20 12 20z"/>',
  infinity: '<path d="M12 12c-2-2.6-3.6-4-5.6-4a4 4 0 0 0 0 8c2 0 3.6-1.4 5.6-4zm0 0c2 2.6 3.6 4 5.6 4a4 4 0 0 0 0-8c-2 0-3.6 1.4-5.6 4z"/>',
  leaf: '<path d="M5 19C5 10.2 10.2 5 19 5c0 8.8-5.2 14-14 14z"/><path d="M5 19l8.5-8.5"/>',
  sun: '<circle cx="12" cy="12" r="3.6"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  moon: '<path d="M15.5 3.8a8.5 8.5 0 1 0 4.7 13.6A7.2 7.2 0 0 1 15.5 3.8z"/>',
  hand: '<path d="M7 11V5.5a1.5 1.5 0 0 1 3 0V10m0-1.5v-5a1.5 1.5 0 0 1 3 0V10m0-4.5a1.5 1.5 0 0 1 3 0V11m0-2.5a1.5 1.5 0 0 1 3 0V15a7 7 0 0 1-7 7h-1a6.5 6.5 0 0 1-5.4-2.9L3.4 15.6a1.6 1.6 0 0 1 2.5-2L7 15"/>',
};
const icon = (name, cls = 'icon') =>
  `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><g fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round">${ICONS[name]}</g></svg>`;

// Logo : croissant de lune et étoiles
const MARK = `<svg class="mark" viewBox="0 0 40 40" aria-hidden="true" focusable="false"><path fill="currentColor" d="M22.5 5.5a14.5 14.5 0 1 0 12 22.6A12.2 12.2 0 0 1 22.5 5.5z"/><path fill="currentColor" d="M27 9.5c.35 2.6 1.1 3.4 3.5 3.8-2.4.4-3.15 1.2-3.5 3.8-.35-2.6-1.1-3.4-3.5-3.8 2.4-.4 3.15-1.2 3.5-3.8z"/><circle fill="currentColor" cx="33.5" cy="7" r=".9"/><circle fill="currentColor" cx="31" cy="20.5" r=".6"/></svg>`;

// ---------- Paysage : crêtes de montagnes générées (graine fixe) ----------
function mountains() {
  let seed = 7;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  const ridge = (base, amp, step, fill) => {
    let d = `M0 320L0 ${base}`;
    let y = base;
    for (let x = 0; x <= 1440; x += step) {
      y = Math.max(base - amp, Math.min(base + amp * 0.4, y + (rnd() - 0.55) * amp * 0.9));
      d += `L${x} ${y.toFixed(0)}`;
    }
    return `<path d="${d}L1440 320Z" fill="${fill}"/>`;
  };
  return `<svg class="mountains" viewBox="0 0 1440 320" preserveAspectRatio="none" aria-hidden="true" focusable="false">
${ridge(150, 90, 48, '#A9788F')}${ridge(205, 70, 36, '#7E5670')}${ridge(255, 45, 24, '#583B52')}${ridge(292, 22, 16, '#3B2739')}</svg>`;
}

const SKY = `<svg class="sky" viewBox="0 0 1440 400" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><g fill="#FFF3E6">${[
  [140, 70, 1.4], [260, 150, 1], [410, 40, 1.2], [610, 110, 0.9], [890, 60, 1.3], [1010, 150, 1], [1180, 50, 1.1], [1330, 120, 1.4], [760, 30, 1], [60, 190, 0.8], [1260, 220, 0.9],
].map(([x, y, r], i) => `<circle class="twinkle" style="animation-delay:${(i * 0.7).toFixed(1)}s" cx="${x}" cy="${y}" r="${r}"/>`).join('')}
<path class="twinkle" style="animation-delay:.4s" d="M330 95c.5 4 1.6 5.2 5 5.8-3.4.6-4.5 1.8-5 5.8-.5-4-1.6-5.2-5-5.8 3.4-.6 4.5-1.8 5-5.8z"/><path class="twinkle" style="animation-delay:2.2s" d="M1110 100c.5 4 1.6 5.2 5 5.8-3.4.6-4.5 1.8-5 5.8-.5-4-1.6-5.2-5-5.8 3.4-.6 4.5-1.8 5-5.8z"/></g></svg>`;

// ---------- Avis clients ----------
const EXAMPLE_REVIEWS = [
  { name: 'Prénom N.', city: 'Ville', jewel: 'Bracelet sur mesure', text: 'Emplacement d’avis : collez ici le texte d’un avis reçu (Google, Facebook, message d’une cliente avec son accord). Deux à quatre phrases suffisent.' },
  { name: 'Prénom N.', city: 'Ville', jewel: 'Conseil en lithothérapie', text: 'Les avis les plus convaincants racontent le projet, l’accueil à l’atelier et le ressenti en portant le bijou.' },
  { name: 'Prénom N.', city: 'Ville', jewel: 'Transformation d’un bijou', text: 'Indiquez le prénom et l’initiale du nom, la ville et le type de bijou, avec l’accord de la personne.' },
];
function reviewsSection(preview) {
  const real = (cfg.reviews || []).filter((r) => r.text && r.name);
  const examples = !real.length;
  if (examples && !preview) return '';
  const list = examples ? EXAMPLE_REVIEWS : real;
  const stars = (n = 5) => `<p class="review-stars" aria-label="Note : ${n} sur 5">${'✦'.repeat(n)}<span aria-hidden="true">${'✦'.repeat(5 - n)}</span></p>`;
  const cards = list
    .map((r) => `<figure class="review${examples ? ' review--example' : ''}">
${examples ? '<p class="review-badge">Exemple · à remplacer</p>' : stars(r.rating)}
<blockquote><p>${esc(r.text)}</p></blockquote>
<figcaption><span class="review-name">${esc(r.name)}</span><span class="review-meta">${esc([r.jewel, r.city].filter(Boolean).join(' · '))}${r.source ? ` · avis ${esc(r.source)}` : ''}</span></figcaption>
</figure>`)
    .join('\n');
  return `<section class="section section--paper" aria-labelledby="avis-title">
<div class="wrap">
<div class="section-head section-head--center">
<p class="eyebrow">Avis clients</p>
<h2 id="avis-title">Leurs mots, <em>leurs histoires</em></h2>
${examples ? '<p class="lead">Mise en page prête pour vos vrais avis clients. Ces trois cartes sont des emplacements vides, elles n’apparaissent pas sur le site publié.</p>' : ''}
</div>
<div class="reviews">
${cards}
</div>
${cfg.reviewsUrl ? `<p class="reviews-more"><a class="link-arrow" href="${esc(cfg.reviewsUrl)}" target="_blank" rel="noopener">Lire tous les avis</a></p>` : ''}
</div>
</section>`;
}

// ---------- Jetons ----------
const telHref = cfg.phone.replace(/[^\d+]/g, '');
const baseTokens = {
  ...Object.fromEntries(Object.entries(cfg).filter(([, v]) => typeof v === 'string')),
  year: String(new Date().getFullYear()),
  mark: MARK,
  mountains: mountains(),
  sky: SKY,
  ...Object.fromEntries(Object.keys(ICONS).map((k) => [`icon_${k}`, icon(k)])),
  mapsUrl: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${cfg.city} ${cfg.postalCode}`)}`,
  phoneItem: cfg.phone ? `<li><span class="contact-label">Téléphone</span><a href="tel:${telHref}">${cfg.phone}</a></li>` : '',
  socialLinks: [
    cfg.instagram && `<li><a href="${cfg.instagram}" rel="noopener" target="_blank">Instagram</a></li>`,
    cfg.facebook && `<li><a href="${cfg.facebook}" rel="noopener" target="_blank">Facebook</a></li>`,
  ].filter(Boolean).join(''),
};

const minCss = (css) =>
  css.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\s+/g, ' ').replace(/\s*([{};,>])\s*/g, '$1').replace(/;}/g, '}').trim();

const css = minCss(read('styles.css'));
const mainJs = read('main.js').trim();
const formJs = read('form.js').trim();
const header = read('partials/header.html');
const footer = read('partials/footer.html');
const mobileCta = read('partials/mobile-cta.html');

function jsonLd() {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'JewelryStore',
    name: cfg.name,
    slogan: 'Plus qu’un bijou, une énergie avec toi',
    founder: { '@type': 'Person', name: cfg.owner },
    description: 'Création de bijoux en pierres naturelles, bijoux sur mesure et conseil en lithothérapie à Cuzieu (Loire).',
    url: cfg.url + '/',
    image: cfg.url + '/og.jpg',
    email: cfg.email,
    ...(cfg.phone && { telephone: cfg.phone }),
    address: { '@type': 'PostalAddress', addressLocality: cfg.city, postalCode: cfg.postalCode, addressRegion: cfg.region, addressCountry: 'FR' },
    areaServed: ['Cuzieu', 'Saint-Galmier', 'Montrond-les-Bains', 'Feurs', 'Saint-Étienne', 'Loire'],
    ...([cfg.instagram, cfg.facebook].some(Boolean) && { sameAs: [cfg.instagram, cfg.facebook].filter(Boolean) }),
  };
  return `<script type="application/ld+json">${JSON.stringify(data)}</script>`;
}

const pageFiles = readdirSync(join(SRC, 'pages')).filter((f) => f.endsWith('.html'));

function buildPages(preview) {
  const tokens = { ...baseTokens, reviews: reviewsSection(preview) };
  const fill = (html) =>
    html.replace(/\{\{(\w+)\}\}/g, (m, k) => {
      if (!(k in tokens)) throw new Error(`Jeton inconnu : ${m}`);
      return tokens[k];
    });
  return pageFiles.map((file) => {
    const raw = read(`pages/${file}`);
    const m = raw.match(/^<!--meta\s*([\s\S]*?)-->\s*/);
    if (!m) throw new Error(`Métadonnées manquantes : ${file}`);
    const meta = JSON.parse(m[1]);
    const body = fill(raw.slice(m[0].length));
    const canonical = `${cfg.url}/${file === 'index.html' ? '' : file}`;
    const head = `<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<script>document.documentElement.classList.add('js')</script>
<title>${meta.title}</title>
<meta name="description" content="${meta.description}">
${meta.noindex ? '<meta name="robots" content="noindex">' : `<link rel="canonical" href="${canonical}">`}
<meta name="theme-color" content="#4B3350">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<meta property="og:type" content="website">
<meta property="og:locale" content="fr_FR">
<meta property="og:site_name" content="${cfg.name}">
<meta property="og:title" content="${meta.ogTitle || meta.title}">
<meta property="og:description" content="${meta.description}">
<meta property="og:url" content="${canonical}">
<meta property="og:image" content="${cfg.url}/og.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="628">
<meta name="twitter:card" content="summary_large_image">
${meta.preload ? `<link rel="preload" href="/${meta.preload}" as="image">` : ''}
${fontHead()}
<style>${css}</style>
${file === 'index.html' ? jsonLd() : ''}`;
    const nav = fill(header).replace(`data-nav="${meta.nav}"`, 'aria-current="page"').replace(/ data-nav="[^"]*"/g, '');
    const scripts = `<script>${mainJs}</script>${meta.form ? `<script>${formJs}</script>` : ''}`;
    const pageBody = `<a class="skip" href="#contenu">Aller au contenu</a>
${nav}
<main id="contenu">
${body}
</main>
${fill(footer)}
${meta.mobileCta === false ? '' : fill(mobileCta)}
${scripts}`;
    return { file, meta, head, pageBody };
  });
}

// ---------- Écriture ----------
function writeSite(outDir, preview) {
  const built = buildPages(preview);
  rmSync(outDir, { recursive: true, force: true });
  mkdirSync(outDir, { recursive: true });
  for (const { file, head, pageBody } of built) {
    let h = head;
    if (preview) {
      // Aperçu hébergé : chemins relatifs, polices Google (les fichiers locaux ne sont pas publiés).
      h = h.replace(/<link rel="preload" href="\/fonts[^>]*>/g, '').replace(/<style>@font-face[^<]*<\/style>/, '');
      if (localFonts.length) h = h.replace('<style>', `<link rel="stylesheet" href="${GOOGLE_FONTS}"><style>`);
      h = h.replace('href="/favicon.svg"', 'href="favicon.svg"').replace(/<link rel="preload" href="\/([^"]+)" as="image">/, '<link rel="preload" href="$1" as="image">');
    }
    const html =
      preview && file === 'index.html'
        ? `${h}\n${pageBody}\n` // la page principale est enveloppée par l'hébergeur de l'aperçu
        : `<!doctype html>\n<html lang="fr">\n<head>\n${h}\n</head>\n<body>\n${pageBody}\n</body>\n</html>\n`;
    writeFileSync(join(outDir, file), html);
  }
  for (const f of readdirSync(join(SRC, 'static'))) {
    if (preview && f === '_headers') continue;
    copyFileSync(join(SRC, 'static', f), join(outDir, f));
  }
  if (!preview && localFonts.length) {
    mkdirSync(join(outDir, 'fonts'));
    for (const f of localFonts) copyFileSync(join(FONT_DIR, f), join(outDir, 'fonts', f));
  }
  if (!preview) {
    const urls = built
      .filter((p) => !p.meta.noindex)
      .map((p) => `  <url><loc>${cfg.url}/${p.file === 'index.html' ? '' : p.file}</loc></url>`)
      .join('\n');
    writeFileSync(join(outDir, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`);
    writeFileSync(join(outDir, 'robots.txt'), `User-agent: *\nAllow: /\n\nSitemap: ${cfg.url}/sitemap.xml\n`);
  }
  return built;
}

const built = writeSite(join(ROOT, 'dist'), false);
writeSite(join(ROOT, 'preview'), true);

const kb = (s) => (Buffer.byteLength(s) / 1024).toFixed(1) + ' Ko';
console.log(`✓ ${built.length} pages · CSS ${kb(css)} · JS ${kb(mainJs)} (+ formulaire ${kb(formJs)})`);
console.log(localFonts.length ? `✓ Polices locales : ${localFonts.length}` : '⚠ Polices servies par Google Fonts — lancez `npm run fonts` avant le déploiement.');
if (!cfg.formEndpoint) console.log('⚠ formEndpoint vide : le formulaire prépare un email au lieu de l’envoyer (voir README).');
if (!(cfg.reviews || []).length) console.log('⚠ Aucun avis dans site.config.json : la section avis est masquée sur le site (visible en exemple dans l’aperçu).');
