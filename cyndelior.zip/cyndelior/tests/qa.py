"""QA automatique : structure, liens, débordements responsive, console, formulaire.
Usage : npm test   (ou python3 tests/qa.py [--shots DOSSIER])"""
import functools, http.server, json, re, sys, threading
from html.parser import HTMLParser
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
SHOTS = Path(sys.argv[sys.argv.index("--shots") + 1]) if "--shots" in sys.argv else None
PAGES = sorted(p.name for p in DIST.glob("*.html"))
WIDTHS = [320, 390, 768, 1024, 1440, 1920]
failures = []

def check(cond, msg):
    if not cond:
        failures.append(msg)
        print("  ✗", msg)

# ---------- 1. Analyse statique ----------
VOID = {"area","base","br","col","embed","hr","img","input","link","meta","source","track","wbr","path","polygon","rect","stop"}
class Doc(HTMLParser):
    def __init__(self):
        super().__init__(); self.stack=[]; self.errors=[]; self.ids=[]; self.links=[]; self.h=[]; self.labels=set(); self.controls=[]; self._h=None
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a: self.ids.append(a["id"])
        if tag == "a" and "href" in a: self.links.append(a["href"])
        if tag == "label" and "for" in a: self.labels.add(a["for"])
        if tag in ("input","select","textarea") and a.get("type") not in ("hidden",): self.controls.append(a.get("id"))
        if re.fullmatch(r"h[1-6]", tag): self.h.append(int(tag[1]))
        if tag == "img":
            if "alt" not in a: self.errors.append("img sans alt")
            if not (a.get("width") and a.get("height")): self.errors.append(f"img sans dimensions {a.get('src')}")
            self.links.append(a.get("src", ""))
        if tag not in VOID and not self.get_starttag_text().endswith("/>"): self.stack.append(tag)
    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
    def handle_endtag(self, tag):
        if tag in VOID: return
        if not self.stack or self.stack[-1] != tag:
            self.errors.append(f"balise </{tag}> inattendue (ouverte : {self.stack[-1] if self.stack else '-'})");
            if tag in self.stack:
                while self.stack and self.stack.pop() != tag: pass
        else: self.stack.pop()

print("▸ Analyse statique")
for name in PAGES:
    html = (DIST / name).read_text()
    d = Doc(); d.feed(html)
    check(not d.errors, f"{name}: {d.errors[:3]}")
    check(not d.stack, f"{name}: balises non fermées {d.stack}")
    check(d.h.count(1) == 1, f"{name}: {d.h.count(1)} H1")
    jumps = [(a, b) for a, b in zip(d.h, d.h[1:]) if b > a + 1]
    check(not jumps, f"{name}: saut de niveau de titre {jumps}")
    dup = {i for i in d.ids if d.ids.count(i) > 1}
    check(not dup, f"{name}: id dupliqués {dup}")
    check(all(c in d.labels for c in d.controls if c), f"{name}: champ sans label {[c for c in d.controls if c and c not in d.labels]}")
    check("<title>" in html and 'name="description"' in html, f"{name}: title/description manquants")
    t = re.search(r"<title>(.*?)</title>", html).group(1)
    desc = re.search(r'name="description" content="([^"]*)"', html).group(1)
    check(len(t) <= 75, f"{name}: title trop long ({len(t)})")
    if "noindex" not in html: check(110 <= len(desc) <= 160, f"{name}: description {len(desc)} caractères")
    check("{{" not in html, f"{name}: jeton non remplacé")
    for href in d.links:
        if href.startswith(("http", "mailto:", "tel:")): continue
        f, _, anchor = href.partition("#")
        target = DIST / (f or name)
        check(target.exists(), f"{name}: lien cassé {href}")
        if anchor and target.exists() and anchor not in ("devis", "rendez-vous", "question"):
            check(f'id="{anchor}"' in target.read_text(), f"{name}: ancre absente {href}")
ld = re.search(r'<script type="application/ld\+json">(.*?)</script>', (DIST / "index.html").read_text())
check(ld and json.loads(ld.group(1))["@type"] == "JewelryStore", "JSON-LD absent ou invalide")
check((DIST / "sitemap.xml").exists() and (DIST / "robots.txt").exists(), "sitemap/robots manquants")

# ---------- 2. Navigateur ----------
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
Handler = functools.partial(Quiet, directory=str(DIST))
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{srv.server_address[1]}"

with sync_playwright() as p:
    browser = p.chromium.launch()
    # Les polices Google ne sont pas joignables ici : on bloque pour éviter les timeouts.
    def page_for(w, h=900, touch=False):
        ctx = browser.new_context(viewport={"width": w, "height": h}, has_touch=touch, is_mobile=touch and w < 800)
        ctx.route(re.compile(r"https://fonts\.(googleapis|gstatic)\.com/.*"), lambda r: r.abort())
        pg = ctx.new_page()
        pg.errors = []
        pg.on("pageerror", lambda e: pg.errors.append(str(e)))
        pg.on("console", lambda m: m.type == "error" and "fonts." not in m.text and "ERR_FAILED" not in m.text and pg.errors.append(m.text))
        return pg

    print("▸ Responsive & console")
    for w in WIDTHS:
        pg = page_for(w, touch=w < 800)
        for name in PAGES:
            pg.goto(f"{BASE}/{name}", wait_until="load")
            over = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            check(over <= 0, f"{name} @{w}px : débordement horizontal de {over}px")
            wide = pg.evaluate("""() => [...document.querySelectorAll('body *')].filter(e => { const r = e.getBoundingClientRect(); return r.width && (r.right > innerWidth + 1 || r.left < -1) && getComputedStyle(e).position !== 'absolute' && !e.closest('.hp, svg'); }).slice(0,3).map(e => e.tagName + '.' + e.className)""")
            check(not wide, f"{name} @{w}px : éléments hors écran {wide}")
            if w < 800:
                small = pg.evaluate("""() => [...document.querySelectorAll('a.btn, button, .nav-list a, .choice label')].filter(e => e.offsetParent && e.getBoundingClientRect().height < 44).map(e => e.textContent.trim().slice(0,30))""")
                check(not small, f"{name} @{w}px : cibles tactiles < 44px {small}")
            if SHOTS and w in (390, 1440):
                SHOTS.mkdir(parents=True, exist_ok=True)
                pg.screenshot(path=str(SHOTS / f"{name[:-5]}-{w}.png"), full_page=True)
        check(not pg.errors, f"@{w}px : erreurs console {pg.errors[:3]}")
        pg.context.close()

    print("▸ Menu mobile")
    pg = page_for(390, touch=True)
    pg.goto(f"{BASE}/index.html")
    check(not pg.is_visible("#nav-principale"), "menu visible avant ouverture")
    pg.click(".menu-toggle")
    check(pg.is_visible("#nav-principale .nav-list a[href='services.html']"), "menu ne s'ouvre pas")
    check(pg.get_attribute(".menu-toggle", "aria-expanded") == "true", "aria-expanded non mis à jour")
    pg.keyboard.press("Escape")
    check(not pg.is_visible("#nav-principale"), "Échap ne ferme pas le menu")
    pg.click(".menu-toggle"); pg.click("#nav-principale a[href='services.html']")
    pg.wait_for_url("**/services.html")
    if SHOTS:
        pg.goto(f"{BASE}/index.html"); pg.click(".menu-toggle"); pg.screenshot(path=str(SHOTS / "menu-390.png"))
    pg.context.close()

    print("▸ Formulaire")
    pg = page_for(390, touch=True)
    pg.goto(f"{BASE}/contact.html#rendez-vous")
    check(pg.is_checked("#type-rdv"), "ancre #rendez-vous ne sélectionne pas le rendez-vous")
    check(pg.is_visible("#date-rdv") and not pg.is_visible("#bijou"), "champs rendez-vous non affichés")
    check(pg.evaluate("document.getElementById('tel').required"), "téléphone non obligatoire pour un rendez-vous")
    pg.click("#submit-btn")
    n_err = pg.locator(".field-error").count()
    check(n_err >= 6, f"validation rendez-vous : {n_err} erreurs affichées")
    check(pg.evaluate("document.activeElement.id") == "format", "le focus ne va pas au premier champ invalide")
    check(pg.evaluate("document.getElementById('date-rdv').min") > "2000", "date minimum non définie")

    pg.goto(f"{BASE}/contact.html#devis")
    pg.fill("#nom", "Claire Martin"); pg.fill("#email", "claire@@exemple")
    pg.click("#submit-btn")
    check("email invalide" in pg.inner_text("#email-err").lower(), "message email invalide absent")
    pg.fill("#email", "claire@exemple.fr")
    check(pg.locator("#email-err").count() == 0, "l'erreur ne disparaît pas une fois corrigée")
    pg.select_option("#bijou", "Bracelet"); pg.select_option("#budget", "100 à 200 €")
    pg.fill("#message", "Un bracelet en quartz rose pour la naissance de ma fille.")
    pg.check("#consent")
    pg.click("#submit-btn")
    pg.wait_for_selector(".form-status--draft")
    draft = pg.input_value(".draft-text")
    check("Demande de devis" in draft and "Bracelet" in draft and "quartz rose" in draft, "brouillon incomplet")
    check("mailto:contact@cyndelior.fr" in pg.get_attribute(".form-status a.btn", "href"), "lien messagerie incorrect")
    if SHOTS: pg.screenshot(path=str(SHOTS / "form-draft-390.png"), full_page=True)

    # Envoi réel simulé (service type Formspree)
    sent = []
    def ok(route):
        sent.append(json.loads(route.request.post_data)); route.fulfill(status=200, body='{"ok":true}', content_type="application/json")
    pg.route("https://formspree.test/**", ok)
    pg.goto(f"{BASE}/contact.html#question")
    pg.evaluate("document.getElementById('contact-form').dataset.endpoint = 'https://formspree.test/f/abc'")
    pg.fill("#nom", "Jean Dupont"); pg.fill("#email", "jean@exemple.fr"); pg.fill("#message", "Faites-vous des bagues ?"); pg.check("#consent")
    pg.fill("#website", "")
    pg.click("#submit-btn")
    pg.wait_for_selector(".form-status--ok")
    check(sent and sent[0]["type"] == "Question" and sent[0]["email"] == "jean@exemple.fr" and "consent" not in sent[0], f"données envoyées incorrectes {sent}")
    check(pg.input_value("#nom") == "", "formulaire non réinitialisé après succès")

    pg.route("https://formspree.fail/**", lambda r: r.fulfill(status=500, body="err"))
    pg.evaluate("document.getElementById('contact-form').dataset.endpoint = 'https://formspree.fail/f/abc'")
    pg.fill("#nom", "Jean Dupont"); pg.fill("#email", "jean@exemple.fr"); pg.fill("#message", "Test erreur"); pg.check("#consent")
    pg.click("#submit-btn")
    pg.wait_for_selector(".form-status--err")
    check("Test erreur" in pg.input_value(".draft-text"), "message perdu en cas d'erreur serveur")
    check(not pg.is_disabled("#submit-btn"), "bouton resté désactivé après erreur")

    # Robot : champ piège rempli -> rien n'est envoyé
    sent.clear()
    pg.evaluate("document.getElementById('contact-form').dataset.endpoint = 'https://formspree.test/f/abc'")
    pg.fill("#nom", "Bot"); pg.fill("#email", "bot@exemple.fr"); pg.fill("#message", "spam"); pg.check("#consent")
    pg.evaluate("document.getElementById('website').value = 'http://spam'")
    pg.click("#submit-btn")
    check(not sent, "le champ piège n'arrête pas les robots")
    check(not [e for e in pg.errors if "500" not in e], f"erreurs console formulaire {pg.errors[:3]}")
    pg.context.close()

    print("▸ Clavier")
    pg = page_for(1440)
    pg.goto(f"{BASE}/index.html")
    pg.keyboard.press("Tab")
    check(pg.evaluate("document.activeElement.className") == "skip" and pg.is_visible(".skip"), "lien d'évitement absent au premier Tab")
    pg.context.close()
    browser.close()

srv.shutdown()
print()
if failures:
    print(f"✗ {len(failures)} problème(s)"); sys.exit(1)
print("✓ Tous les contrôles sont passés")
