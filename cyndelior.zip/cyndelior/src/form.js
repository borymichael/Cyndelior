(() => {
  const form = document.getElementById('contact-form');
  if (!form) return;
  const $ = (id) => document.getElementById(id);
  const status = $('form-status');
  const btn = $('submit-btn');
  const tel = $('tel');
  const msg = $('message');
  const groups = form.querySelectorAll('fieldset[data-group]');
  const recipient = form.dataset.email;
  const delay = form.dataset.delay;
  const TYPES = {
    devis: { button: 'Envoyer ma demande de devis', subject: 'Demande de devis' },
    'rendez-vous': { button: 'Demander ce rendez-vous', subject: 'Demande de rendez-vous' },
    question: { button: 'Envoyer ma question', subject: 'Question' },
  };

  const isoDate = (offsetDays) => {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  };
  $('date-rdv').min = isoDate(1);
  $('echeance').min = isoDate(0);

  // ---------- Type de demande ----------
  let current = 'devis';
  function setType(type) {
    if (!TYPES[type]) return;
    current = type;
    form.querySelector(`input[name="type"][value="${type}"]`).checked = true;
    groups.forEach((g) => { g.disabled = g.dataset.group !== type; });
    const rdv = type === 'rendez-vous';
    tel.required = rdv;
    form.querySelector('[data-tel-opt]').hidden = rdv;
    msg.required = !rdv;
    form.querySelector('[data-msg-opt]').hidden = !rdv;
    btn.textContent = TYPES[type].button;
    form.querySelectorAll('[aria-invalid="true"]').forEach(clearError);
  }
  form.addEventListener('change', (e) => {
    if (e.target.name === 'type') {
      setType(e.target.value);
      try { history.replaceState(null, '', `#${e.target.value}`); } catch (_) { /* aperçu sandboxé */ }
    }
  });
  const fromHash = () => {
    const h = location.hash.slice(1);
    if (TYPES[h]) setType(h);
  };
  window.addEventListener('hashchange', fromHash);
  fromHash();
  if (TYPES[location.hash.slice(1)]) requestAnimationFrame(() => form.scrollIntoView({ block: 'start' }));

  // ---------- Validation ----------
  function errorText(el) {
    const v = el.validity;
    if (v.valueMissing) {
      if (el.type === 'checkbox') return 'Merci de cocher cette case pour envoyer votre demande.';
      if (el.tagName === 'SELECT') return 'Merci de choisir une option.';
      return 'Ce champ est obligatoire.';
    }
    if (v.typeMismatch && el.type === 'email') return 'Adresse email invalide (exemple : prenom@exemple.fr).';
    if (v.patternMismatch && el.type === 'tel') return 'Numéro invalide : indiquez au moins 10 chiffres.';
    if (v.rangeUnderflow) return el.id === 'date-rdv' ? 'Choisissez une date à partir de demain.' : 'Choisissez une date à venir.';
    if (v.badInput) return 'Date invalide.';
    if (v.tooLong) return 'Texte trop long.';
    return 'Valeur invalide.';
  }
  function errorNode(el) {
    const id = `${el.id}-err`;
    let node = $(id);
    if (!node) {
      node = document.createElement('p');
      node.className = 'field-error';
      node.id = id;
      (el.type === 'checkbox' ? el.closest('label') : el).insertAdjacentElement('afterend', node);
    }
    return node;
  }
  function showError(el) {
    errorNode(el).textContent = errorText(el);
    el.setAttribute('aria-invalid', 'true');
    el.setAttribute('aria-describedby', `${el.id}-err`);
  }
  function clearError(el) {
    el.removeAttribute('aria-invalid');
    el.removeAttribute('aria-describedby');
    const node = $(`${el.id}-err`);
    if (node) node.remove();
  }
  const fields = () => [...form.elements].filter((el) => el.willValidate && el.id && el.id !== 'website');
  form.addEventListener('input', (e) => {
    const el = e.target;
    if (el.getAttribute('aria-invalid') === 'true') el.checkValidity() ? clearError(el) : showError(el);
  });
  form.addEventListener('change', (e) => {
    const el = e.target;
    if (el.getAttribute('aria-invalid') === 'true' && el.checkValidity()) clearError(el);
  });

  // ---------- Données ----------
  const LABELS = {
    type: 'Demande', bijou: 'Type de bijou', budget: 'Budget', pierres: 'Pierres / couleurs', echeance: 'Pour le',
    format: 'Format', objet: 'Objet', date: 'Date souhaitée', creneau: 'Créneau', nom: 'Nom', email: 'Email',
    telephone: 'Téléphone', ville: 'Ville', message: 'Message',
  };
  const frDate = (v) => (v ? v.split('-').reverse().join('/') : v);
  function collect() {
    const data = {};
    new FormData(form).forEach((value, key) => {
      if (key === 'website' || key === 'consent') return;
      const v = String(value).trim();
      if (v) data[key] = key === 'date' || key === 'echeance' ? frDate(v) : v;
    });
    data.type = TYPES[current].subject;
    return data;
  }
  const asText = (data) => Object.entries(data).map(([k, v]) => `${LABELS[k] || k} : ${v}`).join('\n');

  // ---------- États ----------
  function setStatus(kind, build) {
    status.className = `form-status form-status--${kind}`;
    status.replaceChildren();
    build(status);
    status.focus({ preventScroll: true });
    status.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
  const el = (tag, text, cls) => {
    const n = document.createElement(tag);
    if (text) n.textContent = text;
    if (cls) n.className = cls;
    return n;
  };
  function setLoading(on) {
    btn.disabled = on;
    form.setAttribute('aria-busy', String(on));
    btn.textContent = on ? 'Envoi en cours…' : TYPES[current].button;
  }

  function showSuccess(data) {
    const first = (data.nom || '').split(' ')[0];
    setStatus('ok', (s) => {
      s.append(
        el('h3', `Merci${first ? ' ' + first : ''}, votre demande est bien envoyée.`),
        el('p', `Je vous réponds sous ${delay} à l’adresse ${data.email}. Pensez à vérifier vos courriers indésirables.`),
      );
    });
    form.reset();
    setType(current);
  }

  function showDraft(data, reason) {
    const subject = `${data.type} · ${data.nom}`;
    const body = asText(data);
    setStatus(reason ? 'err' : 'draft', (s) => {
      s.append(
        el('h3', reason ? 'L’envoi n’a pas abouti' : 'Votre message est prêt'),
        el('p', reason
          ? `${reason} Votre message n’est pas perdu : copiez-le et envoyez-le par email à l’adresse ci-dessous.`
          : 'Pour finaliser, envoyez-le depuis votre messagerie à l’adresse ci-dessous. Tout est déjà rédigé.'),
      );
      const row = el('div', '', 'copy-row');
      row.append(el('code', recipient));
      const copyAddr = el('button', 'Copier l’adresse', 'btn btn--ghost');
      copyAddr.type = 'button';
      row.append(copyAddr);
      const area = el('textarea', '', 'draft-text');
      area.readOnly = true;
      area.value = `Objet : ${subject}\n\n${body}`;
      area.setAttribute('aria-label', 'Votre message');
      const actions = el('div', '', 'btn-row');
      const copyMsg = el('button', 'Copier le message', 'btn btn--primary');
      copyMsg.type = 'button';
      const mail = el('a', 'Ouvrir ma messagerie', 'btn btn--ghost');
      mail.href = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      actions.append(copyMsg, mail);
      s.append(row, area, actions);
      const copy = (text, button, fallbackEl) => {
        const done = () => { const t = button.textContent; button.textContent = 'Copié ✓'; setTimeout(() => { button.textContent = t; }, 2000); };
        const select = () => { if (fallbackEl.select) fallbackEl.select(); else getSelection().selectAllChildren(fallbackEl); };
        try { navigator.clipboard.writeText(text).then(done, select); } catch (_) { select(); }
      };
      copyAddr.addEventListener('click', () => copy(recipient, copyAddr, row.querySelector('code')));
      copyMsg.addEventListener('click', () => copy(area.value, copyMsg, area));
    });
  }

  // ---------- Envoi ----------
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const invalid = fields().filter((f) => !f.checkValidity());
    fields().forEach((f) => (invalid.includes(f) ? showError(f) : clearError(f)));
    if (invalid.length) { invalid[0].focus(); return; }

    const data = collect();
    if ($('website').value) { showSuccess(data); return; } // robot : on ne transmet rien

    const endpoint = form.dataset.endpoint;
    if (!endpoint) { showDraft(data); return; }

    setLoading(true);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, _subject: `[Cyndélior] ${data.type} · ${data.nom}`, _replyto: data.email }),
        signal: ctrl.signal,
      });
      if (!res.ok) throw new Error(String(res.status));
      setLoading(false);
      showSuccess(data);
    } catch (err) {
      setLoading(false);
      showDraft(data, err.name === 'AbortError' ? 'Le serveur met trop de temps à répondre.' : 'Le service d’envoi est momentanément indisponible.');
    } finally {
      clearTimeout(timer);
    }
  });
})();
